from fastapi.testclient import TestClient

from app.core.orchestrator import RecruitingWorkforce
from app.main import app
from app.models.domain import ApprovalStatus, CandidateStage


def test_workforce_runs_end_to_end():
    run = RecruitingWorkforce().run()
    assert run.status == "Waiting for human approval"
    assert len(run.candidates) >= 6
    assert len(run.traces) >= 6
    assert len(run.workflow) == 7
    assert len(run.memory) >= len(run.candidates)
    assert run.candidates[0].score >= run.candidates[-1].score
    assert len(run.pending_approvals) == 3
    assert run.self_improvements


def test_approval_gate_changes_candidate_stage():
    engine = RecruitingWorkforce()
    run = engine.run()
    approval = run.pending_approvals[0]
    candidate_id = approval.payload["candidate_id"]
    engine.apply_approval(run, approval.id, True)
    assert approval.status == ApprovalStatus.approved
    candidate = next(c for c in run.candidates if c.id == candidate_id)
    assert candidate.stage == CandidateStage.outreach_ready


def test_http_pages_and_api_work():
    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert "Executive Command Center" in response.text
    latest = client.get("/api/runs/latest")
    assert latest.status_code == 200
    data = latest.json()
    assert data["approvals"]
    candidate_id = data["candidates"][0]["id"]
    detail = client.get(f"/candidates/{candidate_id}")
    assert detail.status_code == 200
    assert "Fit Score Breakdown" in detail.text
    approval_id = data["approvals"][0]["id"]
    approved = client.post(f"/api/approvals/{approval_id}/approve")
    assert approved.status_code == 200
