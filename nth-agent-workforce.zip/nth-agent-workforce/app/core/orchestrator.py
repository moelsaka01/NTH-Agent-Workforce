from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from app.agents.candidate_evaluator import CandidateEvaluatorAgent
from app.agents.candidate_researcher import CandidateResearcherAgent
from app.agents.outreach_agent import OutreachAgent
from app.agents.ranking_agent import RankingAgent
from app.agents.recruiting_director import RecruitingDirectorAgent
from app.agents.self_improvement_agent import SelfImprovementAgent
from app.models.domain import AgentStatus, AgentTrace, ApprovalStatus, CandidateStage, JobSpec, MemoryItem, WorkforceRun
from app.services.sample_data import load_seed_candidates


class RecruitingWorkforce:
    def __init__(self) -> None:
        self.director = RecruitingDirectorAgent()
        self.researcher = CandidateResearcherAgent()
        self.evaluator = CandidateEvaluatorAgent()
        self.ranker = RankingAgent()
        self.outreach = OutreachAgent()
        self.improver = SelfImprovementAgent()

    def run(self, job: JobSpec | None = None, candidates=None) -> WorkforceRun:
        run = WorkforceRun(id=str(uuid4()), job=job or JobSpec(), candidates=list(candidates) if candidates is not None else load_seed_candidates())
        run.status = "Running"
        for agent in [self.director, self.researcher, self.evaluator, self.ranker, self.outreach, self.improver]:
            agent.ensure_state(run)
        self.director.plan(run)
        self.researcher.research(run)
        self.evaluator.evaluate(run)
        self.ranker.rank(run)
        self.outreach.draft(run)
        self.improver.reflect(run)
        run.status = "Waiting for human approval"
        run.updated_at = datetime.utcnow()
        return run

    @staticmethod
    def apply_approval(run: WorkforceRun, approval_id: str, approved: bool) -> WorkforceRun:
        found = None
        for approval in run.approvals:
            if approval.id == approval_id:
                found = approval
                break
        if found is None:
            raise KeyError(f"Approval item not found: {approval_id}")
        found.status = ApprovalStatus.approved if approved else ApprovalStatus.rejected
        candidate_id = found.payload.get("candidate_id")
        for candidate in run.candidates:
            if candidate.id == candidate_id:
                candidate.stage = CandidateStage.outreach_ready if approved else CandidateStage.rejected
                candidate.agent_notes.append("Human approved outreach." if approved else "Human rejected outreach.")
                best_proof = candidate.projects[0] if candidate.projects else "no captured project proof"
                run.memory.append(
                    MemoryItem(
                        id=f"mem-human-{candidate.id}-{approval_id}",
                        category="human_gate_pattern",
                        source="Human Approval Gate",
                        content=(
                            f"{'Positive' if approved else 'Negative'} calibration pattern: {candidate.name} was {'approved' if approved else 'rejected'} after review. "
                            f"Best proof was {best_proof}. Future similar profiles should be {'promoted faster when proof strength remains strong' if approved else 'held until stronger production evidence is found'}."
                        ),
                    )
                )
        run.traces.append(AgentTrace(agent="Human Approval Gate", event="approval_decision", message=f"{'Approved' if approved else 'Rejected'} {found.title}; calibration memory updated.", metadata={"approval_id": approval_id, "approved": approved}))
        if not run.pending_approvals:
            approved_count = len([item for item in run.approvals if item.status == ApprovalStatus.approved])
            rejected_count = len([item for item in run.approvals if item.status == ApprovalStatus.rejected])
            for step in run.workflow:
                if step.id == "approve":
                    step.status = AgentStatus.completed
                    step.outputs.append(f"Approval gate complete: {approved_count} approved, {rejected_count} rejected")
                if step.id == "outreach":
                    step.status = AgentStatus.completed if approved_count else AgentStatus.blocked
                    step.outputs.append(f"{approved_count} outreach drafts ready after human review")
            for agent in run.agents:
                if agent.name == "Outreach Agent":
                    agent.status = AgentStatus.completed if approved_count else AgentStatus.blocked
                    agent.current_task = f"{approved_count} approved outreach drafts ready" if approved_count else "No outreach approved"
                    agent.last_event = agent.current_task
            run.traces.append(AgentTrace(agent="Outreach Agent", event="outreach_ready", message=f"Prepared {approved_count} approved outreach drafts after human review.", metadata={"approved": approved_count, "rejected": rejected_count}))
            run.status = "Outreach ready" if approved_count else "Approval complete"
        elif any(c.stage == CandidateStage.outreach_ready for c in run.candidates):
            run.status = "Partial outreach ready"
        run.updated_at = datetime.utcnow()
        return run
