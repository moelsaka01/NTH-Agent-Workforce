from pathlib import Path
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.api.routes import router
from app.services.store import store

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(title="Nth Agent Workforce", version="2.1.0")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.include_router(router)

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "app": "Nth Agent Workforce"}


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request) -> HTMLResponse:
    run = store.latest()
    return templates.TemplateResponse("dashboard.html", {"request": request, "run": run})


@app.get("/candidates", response_class=HTMLResponse)
def candidates_page(request: Request) -> HTMLResponse:
    run = store.latest()
    return templates.TemplateResponse("candidates.html", {"request": request, "run": run})


@app.get("/sources", response_class=HTMLResponse)
def sources_page(request: Request) -> HTMLResponse:
    run = store.latest()
    return templates.TemplateResponse("sources.html", {"request": request, "run": run})


@app.get("/approvals", response_class=HTMLResponse)
def approvals_page(request: Request) -> HTMLResponse:
    run = store.latest()
    return templates.TemplateResponse("approvals.html", {"request": request, "run": run})


@app.get("/workflow", response_class=HTMLResponse)
def workflow_page(request: Request) -> HTMLResponse:
    run = store.latest()
    return templates.TemplateResponse("workflow.html", {"request": request, "run": run})


@app.get("/memory", response_class=HTMLResponse)
def memory_page(request: Request) -> HTMLResponse:
    run = store.latest()
    grouped_memory = {}
    for item in run.memory:
        grouped_memory.setdefault(item.category, []).append(item)
    return templates.TemplateResponse("memory.html", {"request": request, "run": run, "grouped_memory": grouped_memory})


@app.get("/self-improve", response_class=HTMLResponse)
def self_improve_page(request: Request) -> HTMLResponse:
    run = store.latest()
    return templates.TemplateResponse("self_improve.html", {"request": request, "run": run})


@app.get("/candidates/{candidate_id}", response_class=HTMLResponse)
def candidate_detail(candidate_id: str, request: Request) -> HTMLResponse:
    try:
        candidate = store.get_candidate(candidate_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    run = store.latest()
    return templates.TemplateResponse("candidate.html", {"request": request, "run": run, "candidate": candidate})
