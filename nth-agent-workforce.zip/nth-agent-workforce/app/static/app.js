(function () {
  const workflowMessages = [
    'Mission scoped: the role became a concrete agentic-backend hiring brief',
    'Evidence collected: shipped projects were separated from resume keywords',
    'Rubric applied: agentic fit and systems depth were scored as separate signals',
    'Shortlist formed: candidates advanced because proof aligned with the role',
    'Human gate active: outreach remains blocked until reviewer approval',
    'Behavior updated: decisions become next-run sourcing and ranking rules'
  ];

  function countItems(run, status) {
    return (run.approvals || []).filter((item) => item.status === status).length;
  }

  function countCandidates(run, stage) {
    return (run.candidates || []).filter((item) => item.stage === stage).length;
  }

  function setText(selector, value) {
    document.querySelectorAll(selector).forEach((node) => {
      node.textContent = value;
    });
  }

  function updateGlobalCounters(run) {
    const pending = countItems(run, 'Pending');
    const approved = countItems(run, 'Approved');
    const rejected = countItems(run, 'Rejected');
    const outreachReady = countCandidates(run, 'Outreach Ready');

    setText('[data-count="pending-approvals"]', pending);
    setText('[data-count="approved-approvals"]', approved);
    setText('[data-count="rejected-approvals"]', rejected);
    setText('[data-count="outreach-ready"]', outreachReady);
    setText('[data-run-status]', run.status || 'Updated');

    document.querySelectorAll('[data-pending-badge]').forEach((badge) => {
      badge.textContent = pending;
    });
  }

  function markApprovalCard(card, approved) {
    if (!card) return;
    const statusText = approved ? 'APPROVED' : 'REJECTED';
    card.classList.remove('pending');
    card.classList.add(approved ? 'approved' : 'rejected');
    card.querySelectorAll('form').forEach((form) => form.remove());

    let label = card.querySelector('[data-decision-status]');
    if (!label) {
      label = document.createElement('span');
      label.setAttribute('data-decision-status', '');
      card.prepend(label);
    }
    label.textContent = statusText;
  }

  function updateHomeApprovalPanel(run) {
    const homePanel = document.querySelector('[data-approval-home]');
    if (!homePanel) return;

    const pending = countItems(run, 'Pending');
    const approved = countItems(run, 'Approved');
    const rejected = countItems(run, 'Rejected');
    const outreachReady = countCandidates(run, 'Outreach Ready');

    const title = homePanel.querySelector('[data-approval-home-title]');
    if (title) {
      title.textContent = pending ? 'Human Review Inbox' : 'Approval Gate Complete';
    }

    if (!pending) {
      const body = homePanel.querySelector('[data-approval-home-body]');
      if (body) {
        body.innerHTML = `
          <div class="approval-summary mission-summary">
            <div><b>${approved}</b><span>approved</span></div>
            <div><b>${rejected}</b><span>rejected</span></div>
            <div><b>${outreachReady}</b><span>outreach ready</span></div>
          </div>
        `;
      }
    }
  }

  async function handleApprovalSubmit(event) {
    const form = event.target.closest('form[data-approval-action]');
    if (!form) return;
    event.preventDefault();

    const button = form.querySelector('button');
    const originalText = button ? button.textContent : '';
    if (button) {
      button.disabled = true;
      button.textContent = 'Saving...';
    }

    try {
      const response = await fetch(form.action, {
        method: 'POST',
        headers: { 'Accept': 'application/json' }
      });
      if (!response.ok) throw new Error('Approval action failed');
      const run = await response.json();
      const approved = form.dataset.approvalAction === 'approve';
      const approvalId = form.dataset.approvalId;

      document.querySelectorAll(`[data-approval-id="${approvalId}"]`).forEach((card) => {
        markApprovalCard(card, approved);
      });
      updateGlobalCounters(run);
      updateHomeApprovalPanel(run);

      const toast = document.querySelector('[data-toast]');
      if (toast) {
        toast.textContent = approved ? 'Approval saved, outreach unlocked.' : 'Rejection saved, candidate moved to nurture.';
        toast.classList.add('show');
        window.setTimeout(() => toast.classList.remove('show'), 2200);
      }
    } catch (error) {
      if (button) {
        button.disabled = false;
        button.textContent = originalText;
      }
      alert('Could not update approval. Please try again.');
    }
  }

  function startLiveTicker() {
    const ticker = document.querySelector('[data-live-ticker]');
    const orgCards = Array.from(document.querySelectorAll('.org-card'));
    if (!ticker || !orgCards.length) return;
    let index = 0;
    window.setInterval(() => {
      ticker.textContent = workflowMessages[index % workflowMessages.length];
      orgCards.forEach((card) => card.classList.remove('active-agent'));
      const card = orgCards[index % orgCards.length];
      if (card) card.classList.add('active-agent');
      index += 1;
    }, 2400);
  }

  document.addEventListener('submit', handleApprovalSubmit);
  document.addEventListener('DOMContentLoaded', startLiveTicker);
})();

(function () {
  document.addEventListener('change', function (event) {
    const input = event.target.closest('[data-file-input]');
    if (!input) return;
    const label = input.closest('.file-drop-zone') || input.closest('.intake-upload');
    const target = label ? label.querySelector('[data-file-name]') : null;
    if (target && input.files && input.files[0]) {
      target.textContent = input.files[0].name;
    }
  });
})();
