from app.agents.base import BaseAgent
from app.models.domain import AgentStatus, CandidateStage, MemoryItem, WorkforceRun


class CandidateResearcherAgent(BaseAgent):
    name = "Candidate Researcher"
    role = "research"
    color = "cyan"

    def research(self, run: WorkforceRun) -> WorkforceRun:
        self.set_status(run, AgentStatus.running, "Extracting candidate evidence")
        required = {skill.lower() for skill in run.job.required_skills}
        for candidate in run.candidates:
            candidate.stage = CandidateStage.researching
            skills = {skill.lower() for skill in candidate.skills}
            required_hits = sorted(required.intersection(skills))
            missing = sorted(required.difference(skills))
            project_signal = candidate.projects[0] if candidate.projects else "No shipped project proof found"
            operating_signal = candidate.signals[0] if candidate.signals else "No operating signal found"
            evidence_depth = "high" if len(candidate.projects) >= 3 and len(candidate.signals) >= 3 else "medium"
            skill_text = ", ".join(required_hits) if required_hits else "no direct required-skill matches"
            missing_text = ", ".join(missing[:3]) if missing else "none"

            candidate.evidence = [
                f"Requirement match: {len(required_hits)} direct matches found ({skill_text}). Missing or weaker signals: {missing_text}.",
                f"Shipped proof: {project_signal}. The researcher treats this as observed product evidence, not a resume keyword.",
                f"Operating signal: {operating_signal}. Used to infer ownership, judgment, and ability to work in production constraints.",
                f"Practical constraints: expected compensation {candidate.expected_salary}, {candidate.years_experience} years experience, evidence depth marked {evidence_depth} before approval.",
            ]
            if "agents" in skills or "llms" in skills:
                candidate.agent_notes.append("Research found direct agent or LLM workflow evidence.")
            if candidate.years_experience < 3:
                candidate.risks.append("May need senior mentorship for enterprise ownership.")
            candidate.stage = CandidateStage.researched
            run.memory.append(
                MemoryItem(
                    id=f"mem-{candidate.id}-research",
                    category="sourcing_lesson",
                    source=self.name,
                    content=(
                        f"When a profile like {candidate.name} appears, prioritize shipped project proof first, "
                        f"then use skills and career signals only as supporting evidence. Best observed proof: {project_signal}."
                    ),
                )
            )
        for step in run.workflow:
            if step.id == "research":
                step.status = AgentStatus.completed
                step.outputs = [f"{len(run.candidates)} profiles researched", "Project proof, signals, and constraints extracted"]
            if step.id == "evaluate":
                step.status = AgentStatus.running
        self.trace(run, "research_completed", f"Researcher converted {len(run.candidates)} profiles into evidence dossiers with shipped proof, signals, and risk flags.")
        self.set_status(run, AgentStatus.completed, "Evidence extraction complete")
        return run
