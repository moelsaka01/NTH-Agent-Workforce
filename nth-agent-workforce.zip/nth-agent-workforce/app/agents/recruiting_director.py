from app.agents.base import BaseAgent
from app.models.domain import AgentStatus, MemoryItem, WorkforceRun, WorkflowStep


class RecruitingDirectorAgent(BaseAgent):
    name = "Recruiting Director"
    role = "orchestrator"
    color = "crimson"

    def plan(self, run: WorkforceRun) -> WorkforceRun:
        self.set_status(run, AgentStatus.running, "Designing the autonomous recruiting org")
        run.workflow = [
            WorkflowStep(id="scope", name="Scope role", owner=self.name, status=AgentStatus.completed, description="Turn the Nth AI challenge into a concrete recruiting mission.", outputs=[run.job.title, run.job.mission]),
            WorkflowStep(id="research", name="Research candidates", owner="Candidate Researcher", status=AgentStatus.running, description="Collect evidence from profiles, projects, skills, and public signals."),
            WorkflowStep(id="evaluate", name="Evaluate fit", owner="Evaluator Agent", status=AgentStatus.waiting, description="Score each candidate with a weighted role-fit rubric."),
            WorkflowStep(id="rank", name="Rank shortlist", owner="Ranking Agent", status=AgentStatus.waiting, description="Promote the best candidates to a human-gated shortlist."),
            WorkflowStep(id="approve", name="Human approval", owner="Human Approval Gate", status=AgentStatus.waiting, description="Block external outreach until the recruiter approves."),
            WorkflowStep(id="outreach", name="Draft outreach", owner="Outreach Agent", status=AgentStatus.waiting, description="Create evidence-backed personalized outreach."),
            WorkflowStep(id="improve", name="Self-improve", owner="Self-Improvement Agent", status=AgentStatus.waiting, description="Learn from pipeline quality and generate next-run changes."),
        ]
        run.memory.append(MemoryItem(id="mem-role-001", category="role", source=self.name, content="Role lesson: Nth AI rewards autonomous agents that execute real work, improve over time, and expose clear handoffs, not generic copilot demos."))
        run.insights.append("Challenge picked: internal agentic org, implemented as an autonomous recruiting pipeline.")
        run.next_actions.append("Approve or reject shortlisted outreach. Approved items become outreach-ready without bypassing the human gate.")
        self.trace(run, "plan_created", "Created org chart, handoffs, workflow stages, and human approval policy.", steps=len(run.workflow))
        self.set_status(run, AgentStatus.completed, "Recruiting mission planned")
        return run
