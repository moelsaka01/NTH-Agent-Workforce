from statistics import mean

from app.agents.base import BaseAgent
from app.models.domain import AgentStatus, MemoryItem, WorkforceRun


class SelfImprovementAgent(BaseAgent):
    name = "Self-Improvement Agent"
    role = "reflection"
    color = "titanium"

    def reflect(self, run: WorkforceRun) -> WorkforceRun:
        self.set_status(run, AgentStatus.running, "Analyzing run quality and generating next-run changes")
        agentic_scores = [c.score_breakdown.get("Agentic AI Fit", 0) for c in run.candidates]
        system_scores = [c.score_breakdown.get("Systems Depth", 0) for c in run.candidates]
        avg_agentic = round(mean(agentic_scores), 1) if agentic_scores else 0
        avg_systems = round(mean(system_scores), 1) if system_scores else 0
        improvements = []
        if avg_agentic < 78:
            improvements.append("Source fewer generic AI engineers and more builders with agents that executed multi-step work end to end.")
        if avg_systems < 82:
            improvements.append("Raise confidence only when backend proof includes deployment, observability, retries, and failure recovery.")
        if len(run.candidates) < run.job.target_candidates:
            improvements.append("Widen the source pool before ranking so one archetype does not dominate the shortlist.")
        improvements.append("Use human approval and rejection decisions as calibration examples for the next shortlist.")
        run.self_improvements = improvements
        run.memory.append(
            MemoryItem(
                id="mem-improvement-001",
                category="learned_behavior",
                source=self.name,
                content=(
                    f"Behavior update: average agentic fit was {avg_agentic} and average systems depth was {avg_systems}. "
                    "Next run should ask for stronger proof before promoting a candidate: shipped agent workflow, eval harness, deployment evidence, and approval-gate design."
                ),
            )
        )
        for step in run.workflow:
            if step.id == "improve":
                step.status = AgentStatus.completed
                step.outputs = improvements[:2]
        self.trace(run, "reflection_completed", "Self-improvement agent converted scoring gaps and human gate outcomes into next-run behavior changes.", improvements=len(improvements))
        self.set_status(run, AgentStatus.completed, "Next-run improvements ready")
        return run
