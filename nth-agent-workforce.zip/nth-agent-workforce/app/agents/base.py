from __future__ import annotations

from datetime import timedelta

from app.models.domain import AgentState, AgentStatus, AgentTrace, WorkforceRun


class BaseAgent:
    name = "Base Agent"
    role = "base"
    color = "titanium"

    def ensure_state(self, run: WorkforceRun) -> AgentState:
        for state in run.agents:
            if state.name == self.name:
                return state
        state = AgentState(name=self.name, role=self.role, color=self.color)
        run.agents.append(state)
        return state

    def set_status(self, run: WorkforceRun, status: AgentStatus, task: str) -> None:
        state = self.ensure_state(run)
        state.status = status
        state.current_task = task
        state.last_event = task

    def trace(self, run: WorkforceRun, event: str, message: str, **metadata: object) -> None:
        # Give the synthetic demo a believable timeline instead of many events sharing
        # the exact same timestamp. This makes the activity feed read like a mission
        # narrative while keeping the run deterministic and lightweight.
        timestamp = run.created_at + timedelta(seconds=22 + len(run.traces) * 47)
        run.traces.append(AgentTrace(timestamp=timestamp, agent=self.name, event=event, message=message, metadata=dict(metadata)))
        state = self.ensure_state(run)
        state.output_count += 1
        state.last_event = message
