from app.agents.base import BaseAgent
from app.models.domain import AgentStatus, CandidateStage, MemoryItem, WorkforceRun


class CandidateEvaluatorAgent(BaseAgent):
    name = "Evaluator Agent"
    role = "evaluation"
    color = "gold"

    def evaluate(self, run: WorkforceRun) -> WorkforceRun:
        self.set_status(run, AgentStatus.running, "Scoring candidates with rubric")
        required = {skill.lower() for skill in run.job.required_skills}
        nice = {skill.lower() for skill in run.job.nice_to_have}
        for candidate in run.candidates:
            candidate.stage = CandidateStage.evaluating
            skills = {skill.lower() for skill in candidate.skills}
            required_hits = len(required.intersection(skills))
            nice_hits = len(nice.intersection(skills))
            technical = min(100, 40 + required_hits * 9 + nice_hits * 4)
            experience = min(100, 50 + candidate.years_experience * 6)
            agentic = min(100, 38 + sum(1 for token in ["agents", "llms", "rag", "evaluation", "human-in-the-loop"] if token in skills) * 13)
            systems = min(100, 42 + sum(1 for token in ["fastapi", "docker", "postgresql", "cloud", "observability", "github actions"] if token in skills) * 9)
            communication = 90 if any("led" in s.lower() or "writes" in s.lower() or "founder" in s.lower() or "communication" in s.lower() for s in candidate.signals) else 78
            salary_fit = 92 if "$160" in candidate.expected_salary or "$170" in candidate.expected_salary or "$180" in candidate.expected_salary else 80
            score = round(technical * 0.25 + experience * 0.16 + agentic * 0.25 + systems * 0.18 + communication * 0.08 + salary_fit * 0.08)
            candidate.score_breakdown = {
                "Technical Skills": int(technical),
                "Experience": int(experience),
                "Agentic AI Fit": int(agentic),
                "Systems Depth": int(systems),
                "Communication": int(communication),
                "Compensation Fit": int(salary_fit),
            }
            candidate.score = int(score)
            candidate.stage = CandidateStage.evaluated

            strongest = sorted(candidate.score_breakdown.items(), key=lambda item: item[1], reverse=True)[:2]
            weakest = sorted(candidate.score_breakdown.items(), key=lambda item: item[1])[:2]
            strongest_text = ", ".join(f"{name} {value}%" for name, value in strongest)
            weakest_text = ", ".join(f"{name} {value}%" for name, value in weakest)

            if score >= 84:
                candidate.recommendation = "Shortlist. Strong evidence for autonomous agent engineering, evaluation discipline, and production backend ownership."
            elif score >= 74:
                candidate.recommendation = "Keep warm. Useful profile, but the evidence is stronger for adjacent workflow or product work than for full autonomous agent ownership."
            else:
                candidate.recommendation = "Nurture. Good background, but not enough direct proof for this agentic backend role yet."
            if candidate.score_breakdown["Agentic AI Fit"] < 70:
                candidate.risks.append("Agentic proof is weaker than top candidates; ask for examples of agents that execute multi-step work without constant manual steering.")
            if candidate.score_breakdown["Systems Depth"] < 65:
                candidate.risks.append("Systems-depth signal is moderate; verify deployment, observability, retry, and failure-handling experience.")
            candidate.agent_notes.append(f"Rubric summary: strongest dimensions were {strongest_text}; watch areas were {weakest_text}.")
            run.memory.append(
                MemoryItem(
                    id=f"mem-{candidate.id}-score",
                    category="rubric_lesson",
                    source=self.name,
                    content=(
                        f"Calibrate future scoring with {candidate.name}: reward {strongest_text}; do not over-rank the profile when "
                        f"{weakest_text} is below the role bar."
                    ),
                )
            )
        for step in run.workflow:
            if step.id == "evaluate":
                step.status = AgentStatus.completed
                step.outputs = ["Weighted rubric applied", "Risk notes generated", "Score tradeoffs captured"]
            if step.id == "rank":
                step.status = AgentStatus.running
        self.trace(run, "evaluation_completed", "Evaluator compared every profile across technical match, agentic autonomy, systems depth, communication, and compensation.")
        self.set_status(run, AgentStatus.completed, "Candidate scoring complete")
        return run
