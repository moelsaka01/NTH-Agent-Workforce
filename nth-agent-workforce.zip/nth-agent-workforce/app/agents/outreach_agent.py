from app.agents.base import BaseAgent
from app.models.domain import AgentStatus, ApprovalItem, CandidateStage, WorkforceRun


class OutreachAgent(BaseAgent):
    name = "Outreach Agent"
    role = "outreach"
    color = "orange"

    def draft(self, run: WorkforceRun) -> WorkforceRun:
        self.set_status(run, AgentStatus.running, "Drafting outreach behind human approval gate")
        for candidate in run.candidates:
            if candidate.stage != CandidateStage.shortlisted:
                continue
            first = candidate.name.split()[0]
            strengths = ", ".join(candidate.skills[:4])
            evidence = candidate.projects[0] if candidate.projects else "your recent engineering work"
            candidate.stage = CandidateStage.approval_pending
            candidate.outreach_draft = (
                f"Hi {first},\n\n"
                f"I came across {evidence} and thought your background in {strengths} could be a strong fit for Nth AI. "
                f"We are building self-improving agents that do enterprise work end to end, autopilot rather than copilot.\n\n"
                f"The reason I am reaching out is specific: your profile scored highly for {run.job.title}, especially around "
                f"{', '.join(list(candidate.score_breakdown.keys())[:3])}. Would you be open to a short conversation?\n\n"
                f"Best,\nNth Agent Workforce"
            )
            run.approvals.append(
                ApprovalItem(
                    id=f"approve-outreach-{candidate.id}",
                    title=f"Approve outreach to {candidate.name}",
                    requested_by=self.name,
                    reason=f"{candidate.score}% fit score. Evidence: {candidate.evidence[1] if candidate.evidence else 'profile evidence available'}",
                    payload={"candidate_id": candidate.id, "draft": candidate.outreach_draft},
                )
            )
        for step in run.workflow:
            if step.id == "approve":
                step.status = AgentStatus.waiting
                step.outputs = [f"{len(run.approvals)} approval requests queued"]
            if step.id == "outreach":
                step.status = AgentStatus.waiting
                step.outputs = ["Drafts generated but blocked until approval"]
        self.trace(run, "outreach_drafted", "Drafted personalized outreach and blocked sending behind human approval.")
        self.set_status(run, AgentStatus.waiting, "Waiting for human approval")
        return run
