from app.agents.base import BaseAgent
from app.models.domain import AgentStatus, CandidateStage, MemoryItem, WorkforceRun


class RankingAgent(BaseAgent):
    name = "Ranking Agent"
    role = "ranking"
    color = "emerald"

    def rank(self, run: WorkforceRun) -> WorkforceRun:
        self.set_status(run, AgentStatus.running, "Ranking candidates and selecting shortlist")
        run.candidates.sort(key=lambda candidate: candidate.score, reverse=True)
        for index, candidate in enumerate(run.candidates, start=1):
            candidate.rank = index
            if index <= 3:
                candidate.stage = CandidateStage.shortlisted
            elif candidate.score >= 74:
                candidate.stage = CandidateStage.evaluated
            else:
                candidate.stage = CandidateStage.nurture
        top = run.candidates[0]
        shortlist = run.candidates[:3]
        run.insights.append(f"Top candidate is {top.name}: strongest combination of shipped agent work, evaluation evidence, and backend ownership.")
        run.memory.append(
            MemoryItem(
                id="mem-ranking-001",
                category="ranking_lesson",
                source=self.name,
                content=(
                    "Ranking behavior learned: shortlist profiles only when project proof, rubric strengths, and operating signals tell the same story. "
                    f"This run selected {', '.join(candidate.name for candidate in shortlist)} because each had direct agent, evaluation, or approval-gated workflow evidence."
                ),
            )
        )
        for step in run.workflow:
            if step.id == "rank":
                step.status = AgentStatus.completed
                step.outputs = ["Evidence alignment checked", f"Best match: {top.name}"]
            if step.id == "approve":
                step.status = AgentStatus.running
        self.trace(run, "ranking_completed", "Ranking agent built the shortlist from evidence alignment, not score alone.", top=[c.name for c in shortlist])
        self.set_status(run, AgentStatus.completed, "Shortlist ready")
        return run
