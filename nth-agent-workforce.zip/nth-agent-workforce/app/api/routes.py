from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import RedirectResponse

from app.services.store import store

router = APIRouter(prefix="/api", tags=["workforce"])


@router.get("/runs/latest")
def latest_run():
    return store.latest()


@router.post("/runs/new")
def new_run():
    return store.create_demo_run()


@router.post("/ui/runs/new")
def new_run_from_ui():
    store.create_demo_run()
    return RedirectResponse(url="/", status_code=303)


@router.post("/ui/runs/reset-demo")
def reset_demo_from_ui():
    store.reset()
    return RedirectResponse(url="/", status_code=303)


@router.post("/ui/sources/reset-demo")
def reset_demo_from_sources_ui():
    store.reset()
    return RedirectResponse(url="/sources", status_code=303)


@router.post("/ui/candidates/upload")
async def upload_candidates_from_ui(file: UploadFile = File(...)):
    try:
        content = await file.read()
        store.create_run_from_upload(file.filename or "candidates.csv", content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return RedirectResponse(url="/candidates", status_code=303)


@router.post("/ui/candidates/manual")
def manual_candidate_from_ui(
    name: str = Form(...),
    title: str = Form(...),
    company: str = Form("Uploaded Workforce"),
    location: str = Form("Remote"),
    email: str = Form(""),
    skills: str = Form(""),
    projects: str = Form(""),
    signals: str = Form(""),
    years_experience: str = Form("4"),
    expected_salary: str = Form("$150k - $190k"),
):
    store.create_run_from_manual(
        {
            "name": name,
            "title": title,
            "company": company,
            "location": location,
            "email": email,
            "skills": skills,
            "projects": projects,
            "signals": signals,
            "years_experience": years_experience,
            "expected_salary": expected_salary,
        }
    )
    return RedirectResponse(url="/candidates", status_code=303)


@router.post("/approvals/{approval_id}/approve")
def approve(approval_id: str):
    try:
        return store.approve(approval_id, True)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/approvals/{approval_id}/reject")
def reject(approval_id: str):
    try:
        return store.approve(approval_id, False)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/ui/approvals/{approval_id}/approve")
def approve_from_ui(approval_id: str):
    store.approve(approval_id, True)
    return RedirectResponse(url="/approvals", status_code=303)


@router.post("/ui/approvals/{approval_id}/reject")
def reject_from_ui(approval_id: str):
    store.approve(approval_id, False)
    return RedirectResponse(url="/approvals", status_code=303)
