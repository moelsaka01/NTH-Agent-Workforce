from __future__ import annotations

import csv
import io
import re
from pathlib import Path
from uuid import uuid4

from app.models.domain import Candidate, CandidateStage


def _split_multi(value: str) -> list[str]:
    if not value:
        return []
    parts = re.split(r"[;|\n]+", value)
    return [part.strip() for part in parts if part.strip()]


def _slug(value: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return base or f"candidate-{uuid4().hex[:8]}"


def candidate_from_fields(fields: dict[str, str]) -> Candidate:
    normalized = {str(k).strip().lower().replace(" ", "_"): str(v).strip() for k, v in fields.items() if k is not None}
    name = normalized.get("name") or normalized.get("candidate") or normalized.get("full_name") or "Imported Candidate"
    title = normalized.get("title") or normalized.get("role") or normalized.get("position") or "Imported Employee"
    company = normalized.get("company") or normalized.get("employer") or normalized.get("team") or "Uploaded Workforce"
    location = normalized.get("location") or normalized.get("city") or "Unknown"
    email = normalized.get("email") or f"{_slug(name)}@example.com"
    skills = _split_multi(normalized.get("skills", "")) or ["Python"]
    projects = _split_multi(normalized.get("projects", "") or normalized.get("work", "") or normalized.get("evidence", ""))
    signals = _split_multi(normalized.get("signals", "") or normalized.get("achievements", "") or normalized.get("notes", ""))
    if not projects:
        projects = [f"Uploaded work sample for {title}: {normalized.get('summary', 'manual evidence pending')}" ]
    if not signals:
        signals = ["Imported profile requires recruiter validation before outreach"]
    try:
        years = int(float(normalized.get("years_experience") or normalized.get("experience") or normalized.get("years") or 4))
    except ValueError:
        years = 4
    salary = normalized.get("expected_salary") or normalized.get("salary") or "$150k - $190k"
    return Candidate(
        id=f"cand-{_slug(name)}",
        name=name,
        title=title,
        company=company,
        location=location,
        email=email,
        github=normalized.get("github", ""),
        linkedin=normalized.get("linkedin", ""),
        skills=skills,
        projects=projects,
        signals=signals,
        years_experience=years,
        expected_salary=salary,
        stage=CandidateStage.sourced,
    )


def parse_csv_bytes(content: bytes) -> list[Candidate]:
    text = content.decode("utf-8-sig", errors="ignore")
    reader = csv.DictReader(io.StringIO(text))
    candidates = [candidate_from_fields(row) for row in reader]
    return _dedupe(candidates)


def parse_xlsx_bytes(content: bytes) -> list[Candidate]:
    try:
        from openpyxl import load_workbook
    except Exception as exc:  # pragma: no cover
        raise ValueError("XLSX import requires openpyxl") from exc
    workbook = load_workbook(io.BytesIO(content), data_only=True)
    sheet = workbook.active
    rows = list(sheet.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(cell or "").strip() for cell in rows[0]]
    candidates: list[Candidate] = []
    for row in rows[1:]:
        fields = {headers[index]: str(value or "") for index, value in enumerate(row) if index < len(headers)}
        if any(value.strip() for value in fields.values()):
            candidates.append(candidate_from_fields(fields))
    return _dedupe(candidates)


def parse_text_to_candidates(text: str) -> list[Candidate]:
    blocks = [block.strip() for block in re.split(r"\n\s*\n", text) if block.strip()]
    candidates: list[Candidate] = []
    for block in blocks:
        lines = [line.strip(" -\t") for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        first = lines[0]
        fields: dict[str, str] = {}
        for line in lines:
            if ":" in line:
                key, value = line.split(":", 1)
                fields[key.strip()] = value.strip()
        if fields:
            candidates.append(candidate_from_fields(fields))
            continue
        parts = [part.strip() for part in re.split(r"[,|]", first) if part.strip()]
        if len(parts) >= 2:
            candidates.append(candidate_from_fields({"name": parts[0], "title": parts[1], "company": parts[2] if len(parts) > 2 else "Uploaded Workforce", "projects": "; ".join(lines[1:])}))
    if not candidates and text.strip():
        candidates.append(candidate_from_fields({"name": "Uploaded Candidate", "projects": text[:1000]}))
    return _dedupe(candidates)


def parse_docx_bytes(content: bytes) -> list[Candidate]:
    try:
        from docx import Document
    except Exception as exc:  # pragma: no cover
        raise ValueError("DOCX import requires python-docx") from exc
    document = Document(io.BytesIO(content))
    text = "\n".join(paragraph.text for paragraph in document.paragraphs)
    return parse_text_to_candidates(text)


def parse_pdf_bytes(content: bytes) -> list[Candidate]:
    try:
        from pypdf import PdfReader
    except Exception as exc:  # pragma: no cover
        raise ValueError("PDF import requires pypdf") from exc
    reader = PdfReader(io.BytesIO(content))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    return parse_text_to_candidates(text)


def parse_upload(filename: str, content: bytes) -> list[Candidate]:
    suffix = Path(filename).suffix.lower()
    if suffix == ".csv":
        return parse_csv_bytes(content)
    if suffix in {".xlsx", ".xlsm"}:
        return parse_xlsx_bytes(content)
    if suffix == ".docx":
        return parse_docx_bytes(content)
    if suffix == ".pdf":
        return parse_pdf_bytes(content)
    if suffix in {".txt", ".md"}:
        return parse_text_to_candidates(content.decode("utf-8", errors="ignore"))
    raise ValueError("Unsupported file type. Upload CSV, XLSX, DOCX, PDF, TXT, or MD.")


def _dedupe(candidates: list[Candidate]) -> list[Candidate]:
    seen: set[str] = set()
    result: list[Candidate] = []
    for candidate in candidates:
        base = candidate.id
        while candidate.id in seen:
            candidate.id = f"{base}-{len(seen) + 1}"
        seen.add(candidate.id)
        result.append(candidate)
    return result
