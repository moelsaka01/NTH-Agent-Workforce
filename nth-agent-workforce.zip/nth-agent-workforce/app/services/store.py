from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from app.core.orchestrator import RecruitingWorkforce
from app.models.domain import Candidate, SourceDataset, WorkforceRun
from app.services.candidate_importer import candidate_from_fields, parse_upload


class InMemoryRunStore:
    def __init__(self) -> None:
        self._runs: dict[str, WorkforceRun] = {}
        self._latest_id: str | None = None
        self._engine = RecruitingWorkforce()

    def latest(self) -> WorkforceRun:
        if self._latest_id is None:
            return self.create_demo_run()
        return self._runs[self._latest_id]

    def _attach_source(self, run: WorkforceRun, *, name: str, kind: str, summary: str) -> WorkforceRun:
        evidence_count = sum(len(candidate.projects) + len(candidate.signals) for candidate in run.candidates)
        run.sources.insert(
            0,
            SourceDataset(
                id=f"src-{uuid4().hex[:8]}",
                name=name,
                kind=kind,
                candidate_count=len(run.candidates),
                evidence_count=evidence_count,
                summary=summary,
            ),
        )
        return run

    def create_demo_run(self) -> WorkforceRun:
        run = self._engine.run()
        self._attach_source(
            run,
            name="Built-in demo candidate pool",
            kind="Demo dataset",
            summary="Six synthetic candidates kept for repeatable testing of ranking, approvals, memory, and workflow behavior.",
        )
        self._runs[run.id] = run
        self._latest_id = run.id
        return run

    def create_run_from_candidates(self, candidates: list[Candidate], *, source_name: str = "Manual candidate input", source_kind: str = "Manual input", source_summary: str = "Candidate evidence entered by the recruiter.") -> WorkforceRun:
        if not candidates:
            raise ValueError("At least one candidate is required")
        run = self._engine.run(candidates=candidates)
        self._attach_source(run, name=source_name, kind=source_kind, summary=source_summary)
        self._runs[run.id] = run
        self._latest_id = run.id
        return run

    def create_run_from_upload(self, filename: str, content: bytes) -> WorkforceRun:
        candidates = parse_upload(filename, content)
        suffix = Path(filename).suffix.lower().lstrip(".").upper() or "file"
        return self.create_run_from_candidates(
            candidates,
            source_name=filename or "Uploaded candidate evidence",
            source_kind=f"{suffix} upload",
            source_summary="Uploaded evidence was parsed into candidate records, project proof, operating signals, approvals, and learned behavior patterns.",
        )

    def create_run_from_manual(self, fields: dict[str, str]) -> WorkforceRun:
        candidate = candidate_from_fields(fields)
        return self.create_run_from_candidates(
            [candidate],
            source_name=f"Manual profile: {candidate.name}",
            source_kind="Manual profile",
            source_summary="Single profile entered by hand for fast testing of the agentic recruiting workflow.",
        )

    def reset(self) -> WorkforceRun:
        self._runs.clear()
        self._latest_id = None
        return self.create_demo_run()

    def approve(self, approval_id: str, approved: bool) -> WorkforceRun:
        run = self.latest()
        run = self._engine.apply_approval(run, approval_id, approved)
        self._runs[run.id] = run
        return run

    def get_candidate(self, candidate_id: str) -> Candidate:
        run = self.latest()
        for candidate in run.candidates:
            if candidate.id == candidate_id:
                return candidate
        raise KeyError(f"Candidate not found: {candidate_id}")


store = InMemoryRunStore()
