from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class CandidateStage(str, Enum):
    sourced = "Sourced"
    researching = "Researching"
    researched = "Researched"
    evaluating = "Evaluating"
    evaluated = "Evaluated"
    shortlisted = "Shortlisted"
    approval_pending = "Approval Pending"
    approved = "Approved"
    outreach_ready = "Outreach Ready"
    outreach_sent = "Outreach Sent"
    interview = "Interview"
    nurture = "Nurture"
    rejected = "Rejected"


class ApprovalStatus(str, Enum):
    pending = "Pending"
    approved = "Approved"
    rejected = "Rejected"


class AgentStatus(str, Enum):
    idle = "Idle"
    running = "Running"
    waiting = "Waiting"
    completed = "Completed"
    blocked = "Blocked"


class Candidate(BaseModel):
    id: str
    name: str
    title: str
    company: str
    location: str
    email: str
    github: str = ""
    linkedin: str = ""
    skills: list[str]
    projects: list[str]
    signals: list[str]
    years_experience: int
    expected_salary: str
    stage: CandidateStage = CandidateStage.sourced
    score: int = 0
    rank: int = 0
    score_breakdown: dict[str, int] = Field(default_factory=dict)
    recommendation: str = ""
    evidence: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    outreach_draft: str = ""
    agent_notes: list[str] = Field(default_factory=list)


class JobSpec(BaseModel):
    id: str = "ai-backend-engineer"
    title: str = "AI Engineer, Backend"
    company: str = "Nth AI"
    location: str = "Remote"
    mission: str = "Build self-improving agents that turn enterprise services into software. Autopilot, not copilot."
    required_skills: list[str] = Field(default_factory=lambda: ["Python", "FastAPI", "LLMs", "RAG", "Agents", "Evaluation"])
    nice_to_have: list[str] = Field(default_factory=lambda: ["LangGraph", "PostgreSQL", "Docker", "Observability", "Human-in-the-loop"])
    seniority: str = "Mid to Senior"
    salary_range: str = "$160k - $220k"
    target_candidates: int = 12


class AgentTrace(BaseModel):
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    agent: str
    event: str
    message: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class AgentState(BaseModel):
    name: str
    role: str
    status: AgentStatus = AgentStatus.idle
    current_task: str = "Waiting for next instruction"
    output_count: int = 0
    quality_score: int = 0
    color: str = "titanium"
    last_event: str = ""


class WorkflowStep(BaseModel):
    id: str
    name: str
    owner: str
    status: AgentStatus = AgentStatus.idle
    description: str
    outputs: list[str] = Field(default_factory=list)


class MemoryItem(BaseModel):
    id: str
    category: str
    content: str
    source: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


class SourceDataset(BaseModel):
    id: str
    name: str
    kind: str
    status: str = "Processed"
    candidate_count: int = 0
    evidence_count: int = 0
    summary: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ApprovalItem(BaseModel):
    id: str
    title: str
    requested_by: str
    reason: str
    status: ApprovalStatus = ApprovalStatus.pending
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class WorkforceRun(BaseModel):
    id: str
    job: JobSpec
    status: str = "Initialized"
    challenge: str = "Challenge 1 - Internal agentic org: recruiting pipeline"
    candidates: list[Candidate] = Field(default_factory=list)
    approvals: list[ApprovalItem] = Field(default_factory=list)
    traces: list[AgentTrace] = Field(default_factory=list)
    agents: list[AgentState] = Field(default_factory=list)
    workflow: list[WorkflowStep] = Field(default_factory=list)
    memory: list[MemoryItem] = Field(default_factory=list)
    sources: list[SourceDataset] = Field(default_factory=list)
    insights: list[str] = Field(default_factory=list)
    next_actions: list[str] = Field(default_factory=list)
    self_improvements: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @property
    def pending_approvals(self) -> list[ApprovalItem]:
        return [item for item in self.approvals if item.status == ApprovalStatus.pending]

    @property
    def approved_approvals(self) -> list[ApprovalItem]:
        return [item for item in self.approvals if item.status == ApprovalStatus.approved]
